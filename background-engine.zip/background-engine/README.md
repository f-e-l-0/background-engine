# Background Processing Engine

Spring Boot 3.3 / Java 21 engine: RabbitMQ quorum queues, TTL-based retry tiers, a parking lot,
Redis idempotency claims, and Postgres as the source of truth with pessimistic locking.

## Run locally
    docker compose up --build
    curl -X POST localhost:8080/api/tasks -H 'Content-Type: application/json' \
         -d '{"tenantId":"acme","type":"demo.echo"}'
    curl localhost:8080/api/tasks/<id>

Admin UI: http://localhost:15672 (engine / engine)

## Test
    mvn test

## Not yet built
Transactional outbox, SLA watchdog, custom metrics beyond the outcome counter, tenant and
W3C trace propagation, parking-lot replay API, Kubernetes manifests, 3-node cluster config,
Liquibase/Flyway zero-downtime migration playbook, blue-green deployment runbook.
