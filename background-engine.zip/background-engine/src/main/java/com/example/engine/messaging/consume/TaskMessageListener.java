package com.example.engine.messaging.consume;

import com.example.engine.common.exception.PermanentFailureException;
import com.example.engine.idempotency.ClaimResult;
import com.example.engine.idempotency.IdempotencyGuard;
import com.example.engine.idempotency.IdempotencyKey;
import com.example.engine.messaging.TaskMessage;
import com.example.engine.messaging.retry.RetryRouter;
import com.example.engine.task.domain.Task;
import com.example.engine.task.handler.TaskHandlerRegistry;
import com.example.engine.task.service.TaskStateService;
import io.micrometer.core.instrument.MeterRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;

import java.util.Optional;

import static com.example.engine.messaging.topology.TopologyConstants.ATTEMPT_HEADER;
import static com.example.engine.messaging.topology.TopologyConstants.MAIN_QUEUE;

/**
 * Thin adapter: decide what happened to a message, then delegate.
 * It holds no business rules. Those live in the task package.
 */
@Component
public class TaskMessageListener {

    private static final Logger log = LoggerFactory.getLogger(TaskMessageListener.class);

    private final IdempotencyGuard idempotency;
    private final TaskStateService state;
    private final TaskHandlerRegistry handlers;
    private final RetryRouter retries;
    private final MeterRegistry metrics;

    public TaskMessageListener(IdempotencyGuard idempotency, TaskStateService state,
                               TaskHandlerRegistry handlers, RetryRouter retries, MeterRegistry metrics) {
        this.idempotency = idempotency;
        this.state = state;
        this.handlers = handlers;
        this.retries = retries;
        this.metrics = metrics;
    }

    @RabbitListener(queues = MAIN_QUEUE, containerFactory = "taskListenerContainerFactory")
    public void onTask(TaskMessage message,
                       @Header(name = ATTEMPT_HEADER, defaultValue = "0") int retriesDone) {
        IdempotencyKey key = IdempotencyKey.of(message.tenantId(), message.taskId());

        // Layer 1: Redis. Cheap, fast duplicate filter.
        ClaimResult claim = idempotency.claim(key);
        if (claim == ClaimResult.ALREADY_DONE) {
            count("duplicate");
            return;
        }
        if (claim == ClaimResult.IN_FLIGHT) {
            // Another worker holds the claim. Do not ack and forget: come back later.
            retries.defer(message, retriesDone);
            count("deferred");
            return;
        }

        // Layer 2: Postgres. The source of truth, even if Redis lost the key.
        Optional<Task> claimed = state.startProcessing(message.taskId());
        if (claimed.isEmpty()) {
            idempotency.release(key);
            count("ineligible");
            return;
        }

        try {
            handlers.require(message.type()).handle(message);
            state.markCompleted(message.taskId());
            idempotency.markDone(key);
            count("completed");
        } catch (PermanentFailureException ex) {
            idempotency.release(key);
            state.markFailed(message.taskId(), ex.getMessage());
            count("parked");
            throw new AmqpRejectAndDontRequeueException("permanent failure: " + ex.getMessage(), ex);
        } catch (RuntimeException ex) {
            idempotency.release(key);
            if (retries.hasBudget(retriesDone)) {
                log.warn("task {} failed on attempt {}, scheduling retry", message.taskId(), retriesDone + 1, ex);
                state.markRetrying(message.taskId(), ex.getMessage());
                retries.scheduleRetry(message, retriesDone);
                count("retried");
            } else {
                log.error("task {} exhausted retries, parking", message.taskId(), ex);
                state.markFailed(message.taskId(), ex.getMessage());
                count("parked");
                throw new AmqpRejectAndDontRequeueException("retries exhausted for " + message.taskId(), ex);
            }
        }
    }

    private void count(String outcome) {
        metrics.counter("engine.task.outcomes", "outcome", outcome).increment();
    }
}
