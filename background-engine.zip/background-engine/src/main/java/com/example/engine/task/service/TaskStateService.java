package com.example.engine.task.service;

import com.example.engine.config.EngineProperties;
import com.example.engine.task.domain.Task;
import com.example.engine.task.domain.TaskTransitions;
import com.example.engine.task.repository.TaskRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Clock;
import java.time.Duration;
import java.util.Optional;
import java.util.UUID;

@Service
public class TaskStateService {

    private final TaskRepository tasks;
    private final Clock clock;
    private final Duration lease;

    public TaskStateService(TaskRepository tasks, Clock clock, EngineProperties props) {
        this.tasks = tasks;
        this.clock = clock;
        this.lease = props.taskLease();
    }

    /** Empty means the task is already finished or held by a live lease. Either way, do not run it. */
    @Transactional
    public Optional<Task> startProcessing(UUID id) {
        return tasks.lockById(id)
                .filter(t -> TaskTransitions.canStart(t.getStatus(), t.getStartedAt(), clock.instant(), lease))
                .map(t -> {
                    t.startProcessing(clock.instant());
                    return t;
                });
    }

    @Transactional
    public void markCompleted(UUID id) {
        require(id).markCompleted(clock.instant());
    }

    @Transactional
    public void markRetrying(UUID id, String error) {
        require(id).markRetrying(error, clock.instant());
    }

    @Transactional
    public void markFailed(UUID id, String error) {
        require(id).markFailed(error, clock.instant());
    }

    private Task require(UUID id) {
        return tasks.lockById(id).orElseThrow(() -> new IllegalStateException("unknown task " + id));
    }
}
